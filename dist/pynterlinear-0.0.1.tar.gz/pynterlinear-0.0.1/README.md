# pynterlinear

The main functionality of `pynterlinear` is generating nicely formatted interlinear text from plain text csv files.
It provides two command-line hooks:

## `csv2word`

## `csv2latex`


You can also use `pynterlinear` in your own python scripts.